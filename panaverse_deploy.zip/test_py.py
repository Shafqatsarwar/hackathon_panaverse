with open("test_output.txt", "w") as f:
    f.write("Hello from Python")
